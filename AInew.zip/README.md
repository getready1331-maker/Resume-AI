# AI Resume Analyzer

Upload a resume, get a strength score, detected skills, career matches, and job
openings listed city by city across India.

## Folder structure

resume-analyzer/
├── app.py              Flask backend (analysis + jobs API)
├── requirements.txt
├── __init__.py
└── static/
    ├── index.html
    ├── style.css
    └── script.js

Keep this structure. Flask serves the three files in `static/`, so the frontend
and backend run on the same address and no CORS problem can occur.

## Run it


pip install -r requirements.txt
python app.py


Open http://127.0.0.1:5000 in the browser. Do not open `index.html` by
double-clicking it — the upload needs the server.

## API

| Method | Endpoint | What it does |
|--------|----------|--------------|
| POST | `/api/analyze` | Form field `resume` (PDF, DOC, DOCX, TXT, max 5 MB). Returns score, skills, career matches and jobs across India. |
| GET | `/api/jobs` | Browse openings without a resume. Filters: `?city=Lucknow`, `?zone=South`, `?role=backend` |
| GET | `/api/health` | Quick check that the server is up. |

## If the page says the server is not running

The line under the file name tells you the state of the connection:

- **Green** — connected, upload will work.
- **Red** — Flask is not running. Open a terminal in this folder and run
  `python app.py`, then reload the page.

The page finds the server by calling `/api/health` on its own address first,
then ports 5000, 5001, 5050 and 8000. It only accepts a server that replies
with `"app": "resume-analyzer"`, so an unrelated project running on one of those
ports is ignored instead of being mistaken for this backend.

Every error path returns JSON, including 404, 405, 413 and 500, so the page can
always show the real reason instead of a generic failure. Debug mode is off by
default for this reason; set `FLASK_DEBUG=1` if you want auto reload while
editing.

## What was fixed

1. **No backend existed.** `app.py` now implements `/api/analyze`, which the
   frontend was already calling.
2. **`API_URL` pointed at a Google documentation page**, so every analysis
   failed. It now points at the server that served the page.
3. **`showResults()` wrote to `resumeSummary`**, an element that was not in the
   HTML, which threw a TypeError and stopped the results from rendering. The
   element was added and all DOM writes are now guarded.
4. **Stray ```` ``` ```` at the end of `Index.html`** printed as visible text.
5. **Job-card CSS was missing** (`job-top`, `company`, `job-meta`,
   `requirements`, `apply-btn`, `empty-jobs`), so cards rendered unstyled.
6. **Skill matching matched inside words** — "JavaScript" registered as "Java".
   Matching is now whole-word.
7. File size and file type are validated on both sides, and every error path
   returns a readable message instead of a crash.

## New: jobs all over India

Results now include openings in 30 cities covering North, South, East, West,
Central, North East India and remote roles. Above the job grid there is a
region dropdown, a role dropdown, and city chips showing the number of openings
per city. Each card shows location, experience, salary range, job type and
posting age, ticks the requirements you already have, and links to a live search
for that role in that city.

## Note on the job data

Listings are generated from the role and city catalogue in `app.py`, so the app
works offline and is stable for a demo. The apply button opens a real search for
that role and city. To use a live jobs feed instead, replace `build_jobs()` with
an API call — `requests` is already in the requirements.
